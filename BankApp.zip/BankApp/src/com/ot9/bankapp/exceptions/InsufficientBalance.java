package com.ot9.bankapp.exceptions;

public class InsufficientBalance extends Exception {

	public InsufficientBalance(String message) {
		super(message);
	}
}
