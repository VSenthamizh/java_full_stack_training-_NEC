package com.nec.empmanagement;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEmployee {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysql");
		// persist()->insert,merge()--update,delete()-->remove,find()--select
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Employee emp=new Employee("suresh",12000,"admin");//ORM
		
		em.persist(emp);

//		Employee emp1 = em.find(Employee.class, 125);
//		System.out.println(emp1);
////		emp1.setEmpSal(17000);
////		em.merge(emp1);
//		em.remove(emp1);

		em.getTransaction().commit();

	}

}
