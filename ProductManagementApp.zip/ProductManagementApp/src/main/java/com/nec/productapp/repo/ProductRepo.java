package com.nec.productapp.repo;

import java.util.List;

import com.nec.productapp.entity.Product;

public interface ProductRepo {

	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract List<Product> getAllProduct();

	public abstract List<Product> getAllBetweenPrice(int intialPrice, int finalPrice);

	public abstract List<Product> getAllByCategory(String productCategory);
}
