package com.nec.productapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.productapp.entity.Product;
import com.nec.productapp.repo.ProductRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {

		return repo.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {
		return repo.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {
		return repo.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {
		return repo.getProduct(productId);
	}

	@Override
	public List<Product> getAllProduct() {
		return repo.getAllProduct();
	}

	@Override
	public List<Product> getAllBetweenPrice(int intialPrice, int finalPrice) {
		return repo.getAllBetweenPrice(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllByCategory(String productCategory) {
		return repo.getAllByCategory(productCategory);
	}

}
