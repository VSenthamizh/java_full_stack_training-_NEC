package com.nec.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan("com.nec.springcore")
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
		Employee emp = (Employee) context.getBean("emp");//<bean
		System.out.println(emp);
		System.out.println(emp.getAddress());
		Address add = (Address) context.getBean("address");
		System.out.println(add);
	}

}
